

let myleads=[""]
let inputEl=document.querySelector("#input-el")
let inputbtn=document.getElementById("input-btn")
let ulEl=document.querySelector("#ul-el")

inputbtn.addEventListener("click",function(){
    myleads.push(inputEl.value)
    inputEl.value=""//clears iput after the value entered to array
     render()
}) 
function render(){
let listItems=""

for(let i=0;i<myleads.length;i++){
    //listItems += "<li><a target='_blank' href='"+myleads[i]+"'>"+myleads[i]+"</a></li>"
    listItems+=`<li><a target='blank' href='${myleads[i]}'>${myleads[i]}</a> </li>`
    }
    ulEl.innerHTML=listItems

}